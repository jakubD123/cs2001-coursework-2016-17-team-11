package com.rathor.hci.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.rathor.hci.R;
import com.rathor.hci.activity.MainActivity;

public class FragEditProfile extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_edit_profile, container, false);
        MainActivity activity = (MainActivity) getActivity();
        activity.mToolbarTitle.setText("Edit Profile");
        TextView mTvSubmit = (TextView) view.findViewById(R.id.tvSubmit);
        TextView mTvAddmore = (TextView) view.findViewById(R.id.tvAddmore);

        mTvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "work in progress", Toast.LENGTH_SHORT).show();
            }
        });
        mTvAddmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).displayViewOther(1, null);

            }
        });

        return view;
    }


}
