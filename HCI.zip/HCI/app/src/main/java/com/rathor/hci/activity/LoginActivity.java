package com.rathor.hci.activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.rathor.hci.R;
import com.rathor.hci.items.User;
import com.rathor.hci.utils.AppSession;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    private EditText mEtEmail, mEtPassword;
    private FirebaseDatabase mFirebaseInstance;
    private DatabaseReference mFirebaseDatabase;
    private DatabaseReference mDatabase;
    private AppSession mSession;
    private ArrayList<User> listUser = new ArrayList<>();
    private ProgressDialog mBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

//        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mSession = AppSession.getInstance(getApplicationContext());
        // mFirebaseDatabase = mFirebaseInstance.getReference("User");

        TextView textView = (TextView) findViewById(R.id.toolbar_title);
        textView.setText("Login");

        mEtEmail = (EditText) findViewById(R.id.editText1);
        mEtPassword = (EditText) findViewById(R.id.editText2);

        ImageView ivBack = (ImageView) findViewById(R.id.iv_left);
        ivBack.setVisibility(View.VISIBLE);

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.tvforgot).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dailogResetPassword();
            }
        });
        findViewById(R.id.tvLogin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
    }

    private void login() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isAcceptingText()) {
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        if (mEtEmail.getText().toString().equals("") || !Patterns.EMAIL_ADDRESS.matcher(mEtEmail.getText().toString()).matches()) {
            Toast.makeText(this, getResources().getString(R.string.Please_enter_correct_email_id), Toast.LENGTH_SHORT).show();
        }
        /*if (mEtEmail.getText().toString().equals("")) {
            Toast.makeText(this, getResources().getString(R.string.Please_enter_phone_number), Toast.LENGTH_SHORT).show();
        }*/ else if (mEtPassword.getText().toString().length() < 4) {
            Toast.makeText(this, getResources().getString(R.string.Please_enter_password), Toast.LENGTH_SHORT).show();
        } else {
            doLogin();
        }
    }

    private void doLogin() {
        mBar = ProgressDialog.show(LoginActivity.this, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        mDatabase.child("User").addListenerForSingleValueEvent(new ValueEventListener() {
            public boolean isFound;

            @Override
            public void onDataChange(final DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    final String enterdEmail = mEtEmail.getText().toString().trim();
                    final String enterdPass = mEtPassword.getText().toString().trim();

                    new AsyncTask<String, Void, Boolean>() {
                        public int pos = 0;
                        public String mEmail, mPass;

                        @Override
                        protected Boolean doInBackground(String... params) {
                            listUser.clear();

                            for (DataSnapshot noteDataSnapshot : snapshot.getChildren()) {
                                User user = noteDataSnapshot.getValue(User.class);
                                listUser.add(user);
                            }

                            for (int i = 0; i < listUser.size(); i++) {
                                if (listUser.get(i).getEmail().equals(enterdEmail)) { // check user is exist in db?
                                    mEmail = listUser.get(i).getEmail();
                                    mPass = listUser.get(i).getPassword();
                                    isFound = true;
                                    pos = i;
                                    break;
                                }
                            }
                            return isFound;
                        }

                        @Override
                        protected void onPostExecute(Boolean s) {
                            super.onPostExecute(s);
                            mBar.dismiss();
                            if (s) { // user found

                                if (enterdEmail.equals(mEmail) && enterdPass.equals(mPass)) { // check user credentials

                                    User item = listUser.get(pos);
                                    mSession.setAccomodation( item.getAccomodation());
                                    mSession.setCourse(item.getCourse());
                                    mSession.setDob( item.getDob());
                                    mSession.setEmail(item.getEmail());
                                    mSession.setDiaplayName(item.getFirstName() + " " + item.getLastName());
                                    mSession.setGender(item.getGender());
                                    mSession.setImageUrl(item.getImagePath());
                                    mSession.setLevel(item.getLevel());
                                    mSession.setPhoneNumber(item.getPhoneNumber());
                                    mSession.setUniversity(item.getUniversity());
                                    mSession.setHasLoging(true);
                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);
                                    finish();
                                    isFound = false;
                                    Toast.makeText(LoginActivity.this, "Welcome ", Toast.LENGTH_SHORT).show();

                                } else {
                                    Toast.makeText(LoginActivity.this, "Please check your login details", Toast.LENGTH_SHORT).show();

                                }


                            } else { // user with this number is not found
                                isFound = false;
                                Toast.makeText(LoginActivity.this, "This user is not exist", Toast.LENGTH_SHORT).show();
                            }

                        }
                    }.execute();

                } else {
                    Toast.makeText(LoginActivity.this, "Found Some Error", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(LoginActivity.this, "Please register atleast one user", Toast.LENGTH_SHORT).show();

            }
        });
    }


    class MyAsyncTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            // Runs on the UI thread before doInBackground()
        }


        @Override
        protected String doInBackground(String... params) {
            return null;
        }

    }


    private void dailogResetPassword() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Reset Password");

        alert.setMessage("Please enter the e-mail address for your account.");
        final EditText email = new EditText(this);
        LinearLayout lay = new LinearLayout(this);
        lay.setOrientation(LinearLayout.VERTICAL);
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        lay.addView(email);
        alert.setView(lay);

        alert.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub

                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(email.getWindowToken(), 0);
                        final String emailID = email.getText().toString();

                        if (emailID.equals("") || !Patterns.EMAIL_ADDRESS.matcher(emailID).matches()) {
                            Toast.makeText(getApplicationContext(), "Please enter a valid email address.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(LoginActivity.this, "Your password has send on your register emial.", Toast.LENGTH_SHORT).show();
                        }


                    }
                }

        );

        alert.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener()

                {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(email.getWindowToken(), 0);
                    }
                }

        );

        alert.show();
    }
}
