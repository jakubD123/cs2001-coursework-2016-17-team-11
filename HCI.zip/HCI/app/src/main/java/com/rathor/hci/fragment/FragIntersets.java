package com.rathor.hci.fragment;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rathor.hci.R;
import com.rathor.hci.activity.MainActivity;
import com.rathor.hci.adapter.CustomGridAdapter;
import com.rathor.hci.items.Interest;
import com.rathor.hci.items.Item;
import com.rathor.hci.utils.AppSession;

import java.util.ArrayList;

public class FragIntersets extends Fragment {

    GridView grid;
    String[] web = {
            "Spiritual",
            "Gaming etc",
            "Fitness",
            "Politics",
            "Entrepreneurs",
            "Music",
            "Photography",
            "Places",
            "Games",
            "Technology",
            "Entertainment",
            "Fashion",
            "Brands",
            "Arts",
            "Travelling",
            "Sports"

    };
    int[] imageId = {
            R.mipmap.spiritual,
            R.mipmap.games,
            R.mipmap.fitness,
            R.mipmap.politics,
            R.mipmap.entrepreneurs,
            R.mipmap.music,
            R.mipmap.photography,
            R.mipmap.places,
            R.mipmap.games,
            R.mipmap.technology,
            R.mipmap.entertainment,
            R.mipmap.fashion,
            R.mipmap.brand,
            R.mipmap.arts,
            R.mipmap.traveling,
            R.mipmap.sports,


    };
    public int count = 1;
    public FirebaseDatabase mFirebaseInstance;
    public DatabaseReference mFirebaseDatabase;
    private AppSession mSession;
    private ArrayList<Item> listItems = new ArrayList<>();
    public ProgressDialog mBar;
    private CustomGridAdapter mAdapter;
    private Boolean isSelected = false;
    private Button btChat;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.frag_intersets, null);
        listItems.clear();
        for (int i = 0; i < web.length; i++) {
            Item item = new Item();
            item.setWeb(web[i]);
            item.setImageId(imageId[i]);
            listItems.add(item);
        }

        mSession = AppSession.getInstance(getActivity());
        mFirebaseInstance = FirebaseDatabase.getInstance();
        MainActivity activity = (MainActivity) getActivity();
        activity.mToolbarTitle.setText("Interest");

        mFirebaseDatabase = mFirebaseInstance.getReference("User/" + mSession.getPhoneNumber()); // if not found this node then it will create auto new
         btChat = (Button) view.findViewById(R.id.btChat);
        //Button btAddmore = (Button) view.findViewById(R.id.btAddmore);

        mAdapter = new CustomGridAdapter(getActivity(), FragIntersets.this, listItems);
        grid = (GridView) view.findViewById(R.id.grid);
        grid.setAdapter(mAdapter);



  /*      mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        mFirebaseDatabase.addValueEventListener(new ValueEventListener() { // for read database
            @Override
            public void onDataChange(final DataSnapshot dataSnapshot) {
                mBar.dismiss();
                for (DataSnapshot noteDataSnapshot : dataSnapshot.getChildren()) {
                    Interest item = noteDataSnapshot.getValue(Interest.class);
                    listUser.add(item);
                }

               *//* for (int i = 0; i < listUser.size(); i++) {
                    String interest = listUser.get(i).getInterest();

                    for (int j = 0; j < web.length; j++) {
                        if (web[j].equals(interest)){
                            adapter.updateList(j);
                        }
                    }
                }*//*
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.e("", "Failed to read user", error.toException());
            }
        });*/

        btChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mAdapter.mSelectedCount == 10){
                    ((MainActivity) getActivity()).displayViewOther(2, null);
                }
                else {
                    Toast.makeText(getActivity(), "please select exact 10 interest", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /*btAddmore.setOnClickListener(new View.OnClickListener() { // for adding custom interest
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());

                alert.setTitle("Add More Interest !");
                //alert.setMessage("type Interest");

                // Set an EditText view to get user input
                final EditText input = new EditText(getActivity());
                alert.setView(input);

                alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        Item item = new Item();
                        item.setWeb(input.getText().toString().trim());
                        item.setImageId(R.mipmap.games);
                        mAdapter.listItem.add(item);
                        mAdapter.updateList();
                    }
                });

                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        // Canceled.
                    }
                });

                alert.show();

            }
        });*/

        return view;
    }


    public void addInterest(String interest, Boolean value, int position) {

        if (value) {
            String test = "value";
            Interest item = new Interest();
            item.setInterest(interest);
            mFirebaseDatabase.child(test + position).setValue(null); //remove child object of same array
            //count++;
        } else {
            String test = "value";
            Interest item = new Interest();
            item.setInterest(interest);
            mFirebaseDatabase.child(test + position).setValue(item); //add another child object of same array
            //count++;
        }
    }

    public void updateButtonStatus(int mSelectedCount) {

        if (mSelectedCount == 10) {
            btChat.setBackgroundColor(ContextCompat.getColor(getActivity(),R.color.colorPrimary));

        } else {
            btChat.setBackgroundColor(ContextCompat.getColor(getActivity(),R.color.light_gray));
        }

    }
}
